﻿namespace Unity.XR.PICO.TOBSupport
{
    public enum PICOCastOptionOrStatusEnum
    {
        OPTION_RESOLUTION_LEVEL=0,
        OPTION_BITRATE_LEVEL=1,
        OPTION_AUDIO_ENABLE=2,
        PICO_CAST_STATUS=3
    }
}