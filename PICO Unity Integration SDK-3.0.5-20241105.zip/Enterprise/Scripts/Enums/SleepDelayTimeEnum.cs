﻿namespace Unity.XR.PICO.TOBSupport
{
    public enum SleepDelayTimeEnum
    {
        FIFTEEN ,
        THIRTY ,
        SIXTY ,
        THREE_HUNDRED ,
        SIX_HUNDRED ,
        ONE_THOUSAND_AND_EIGHT_HUNDRED ,
        NEVER 
    }
}