﻿namespace Unity.XR.PICO.TOBSupport
{
    public enum PICOCastUrlTypeEnum
    {
        NORMAL_URL=0,
        NO_CONFIRM_URL=1,
        RTMP_URL=2
    }
}