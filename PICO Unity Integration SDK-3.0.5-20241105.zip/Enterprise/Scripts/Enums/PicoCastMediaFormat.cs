﻿namespace Unity.XR.PICO.TOBSupport
{
    public class PicoCastMediaFormat
    {
        public int bitrate = -1;//kb
    }
}