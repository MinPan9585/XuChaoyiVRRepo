﻿namespace Unity.XR.PICO.TOBSupport
{
    public enum ControllerPairTimeEnum
    {
        DEFAULT=0,
        FIFTEEN=15,
        SIXTY=60,
        ONE_HUNDRED_AND_TWENTY=120,
        SIX_HUNDRED=600,
        NEVER=-1
    }
}