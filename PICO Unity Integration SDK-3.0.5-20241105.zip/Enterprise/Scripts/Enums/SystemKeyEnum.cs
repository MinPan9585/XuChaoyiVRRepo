﻿namespace Unity.XR.PICO.TOBSupport
{
    public enum SystemKeyEnum
    {
        ENTER_KEY=0,
        BACK_KEY=1,
        VOLUME_KEY=2,
    }
}